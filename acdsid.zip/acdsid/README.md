<h1 align="center">Hallo Guys <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt="hi"><br>acodes was here...</h1>

![My card name](https://cardivo.vercel.app/api?name=adan&description=Hi,%20i%27m%20a%20back%2024y.o%20end%20%20pesan%20saya%20jangan%20pernah%20menyerah%20lakukan%20apa%20yang%20kamu%20lakukan%20hingga%20sukses%20di%20kemudian%20hari%20Nice%20to%20meet%20you%20%F0%9F%91%8B&image=https://avatars.githubusercontent.com/u/74469985?v=4&backgroundColor=%23ecf0f1&instagram=hendrmdn&linkedin=acodes&github=ItsmeHndrr&twitter=adan.nt&pattern=leaf&colorPattern=%23eaeaea)

___
<p align="center">
  <a href="https://api.whatsapp.com/send/?phone=%2B6289688069473&text&app_absent=0"><img src="https://img.shields.io/badge/WhatsApp-00DE07?style=for-the-badge&logo=whatsapp&logoColor=ffffff&link=https://api.whatsapp.com/send/?phone=%2B6289688069473&text&app_absent=0" /></a>
  <a href="https://www.facebook.com/hr999x"><img src="https://img.shields.io/badge/facebook-@hr999x-047DEC?style=for-the-badge&logo=facebook&logoColor=047DEC&link=https://www.facebook.com/hr999x" />
</p>

<p align="center">
  <img src="https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript" />
  <img src="https://img.shields.io/badge/-Node.js-black?style=flat-square&logo=Node.js" />
  <img src="https://img.shields.io/badge/-HTML5-black?style=flat-square&logo=html5&logoColor=e34f26" />
  <img src="https://img.shields.io/badge/-CSS3-black?style=flat-square&logo=css3&logoColor=1572b6" />
  <img src="https://img.shields.io/badge/-Git-black?style=flat-square&logo=git" />
  <img src="https://img.shields.io/badge/-GitHub-black?style=flat-square&logo=github" /> <br>
  <img src="https://img.shields.io/badge/-Python-black?style=flat-square&logo=python" />
  <img src="https://img.shields.io/badge/-React-black?style=flat-square&logo=react" />
  <img src="https://img.shields.io/badge/-Redux-black?style=flat-square&logo=redux" />
  <img src="https://img.shields.io/badge/-Windows-black?style=flat-square&logo=windows" />
  <img src="https://img.shields.io/badge/-VS_Code-black?style=flat-square&logo=visual-studio-code" />
  <img src="https://img.shields.io/badge/-SQLite3-black?style=flat-square&logo=sqlite" />
</p>

<p align="center">
  <a href="https://github.com/ItsmeHndrr"><img src="https://github-readme-stats.vercel.app/api?username=ItsmeHndrr&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&icon_color=fff&hide_border=true&show_icons=true" /></a>
</p>

<p align="center">
  <a href="https://github.com/ItsmeHndrr"><img src="https://github-readme-stats.vercel.app/api/top-langs?username=ItsmeHndrr&bg_color=30,e96443,904e95&title_color=fff&text_color=fff&hide_border=true&show_icons=true&layout=compact" /></a>
</p>

<p align="center">
  <a href="https://github.com/ItsmeHndrr/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=ItsmeHndrr&theme=onedark" /></a>
</p>

<p align="center">
   <img src="https://github-readme-streak-stats.herokuapp.com/?user=ItsmeHndrr" />
</p>

### About Me ⚠️
___

![ItsmeHndrr github stats](https://github-readme-stats.vercel.app/api?username=ItsmeHndrr&layout=compact&theme=tokyonight)
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=ItsmeHndrr&count_private=true&show_icons=true&theme=tokyonight)
<!--
**ItsmeHndrr/ItsmeHndrr** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:
- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
